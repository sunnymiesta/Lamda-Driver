#pragma once

#if !defined(__cplusplus)
#include <stddef.h>
#endif

void generate_random_bytes(size_t n, void *result);
