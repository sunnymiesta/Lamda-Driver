#include "InterruptedException.h"

namespace {
char suppressMSVCWarningLNK4221;
}
