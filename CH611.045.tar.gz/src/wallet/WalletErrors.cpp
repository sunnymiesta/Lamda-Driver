#include "WalletErrors.h"

namespace CryptoNote {
namespace error {

WalletErrorCategory WalletErrorCategory::INSTANCE;

}
}
